import {Router} from "express"

const router = Router()

router.get("/",(req,res)=>{
    res.render("index")
})

router.get("/abc",(req,res)=>{
    res.send("Estás en abc") 
})

export default router